/**
 * 
 * @file student.h
 * @author Jayesh Anil
 * @date 2022-04-07
 * @brief A file consisting of function declarations and a student class 
 */

/**
 * @brief a student type stores first_name, last_name of the student along with his/her id number and grades 
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**<first name of the student */
  char last_name[50]; /**< last name of the student*/
  char id[11]; /**< id number of the student*/
  double *grades; /**< an array of the grades of the student*/
  int num_grades; /**< the total number of grades of the student*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
