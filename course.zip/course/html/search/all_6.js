var searchData=
[
  ['last_5fname_0',['last_name',['../structstudent.html#a88944bf62b0c73fc9d3848707850f0f0',1,'student']]]
];
