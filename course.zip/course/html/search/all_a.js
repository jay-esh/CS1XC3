var searchData=
[
  ['student_0',['student',['../structstudent.html',1,'']]],
  ['student_1',['Student',['../student_8h.html#ae8c079733e2570c4a107caf4b38afc60',1,'student.h']]],
  ['student_2ec_2',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh_3',['student.h',['../student_8h.html',1,'']]],
  ['students_4',['students',['../structcourse.html#a6e4dac952c075a185e836bb126e26eca',1,'course']]],
  ['students_20and_20courses_5',['STUDENTS AND COURSES',['../index.html',1,'']]]
];
