var searchData=
[
  ['title_20students_20and_20courses_20_20_3cbr_3e_0',['title STUDENTS AND COURSES  &lt;br&gt;',['../index.html',1,'']]],
  ['top_5fstudent_1',['top_student',['../course_8c.html#ac1d82150824c7ecd43bab36fb83cd779',1,'course.c']]],
  ['total_5fstudents_2',['total_students',['../struct__course.html#afd5e161f7cf358c13cc8aa868b462006',1,'_course']]]
];
