var searchData=
[
  ['grades_0',['grades',['../structstudent.html#ad00d64b0936e0b9b304cc62819046fec',1,'student']]]
];
