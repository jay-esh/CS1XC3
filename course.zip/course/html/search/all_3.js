var searchData=
[
  ['first_5fname_0',['first_name',['../structstudent.html#a80bc2be4a8e722fdf888408aa89cc783',1,'student']]]
];
