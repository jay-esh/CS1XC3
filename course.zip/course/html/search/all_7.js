var searchData=
[
  ['last_5fname_0',['last_name',['../struct__student.html#a18eb2a90671a2292c017b8f4fbde7eec',1,'_student']]]
];
