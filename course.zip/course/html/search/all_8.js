var searchData=
[
  ['name_0',['name',['../structcourse.html#af79540f1c562b2dae46aa25813d9d782',1,'course']]],
  ['num_5fgrades_1',['num_grades',['../structstudent.html#aa3ab8679d7c760502bf2a9acef39b4bb',1,'student']]]
];
