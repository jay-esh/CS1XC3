var searchData=
[
  ['total_5fstudents_0',['total_students',['../structcourse.html#a2e012cbd6f9199f7940d67c7370abed1',1,'course']]]
];
