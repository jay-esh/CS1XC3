/**
 * @file course.c
 * @author Jayesh Anil
 * @brief Consists of functions dealing with the courses that students take
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief This function enrolls a student into the course by adding the student in the students array in the course type 
 * 
 * @param course - pointer to the course type
 * @param student - pointer to the student type 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    /**
     * Calloc is used here to allocate the memory in the heap to add the first element of the students array
     * when the current student is the first student to enroll in the course.
     * 
     */
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      /**
       * Realloc is used here to realloc the size of the array in the heap (add by 1) 
       * to add one more student into the array of students who have already enrolled in the course 
       */
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // adding the student in the student array as a pointer 
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This function prints the course in the terminal 
 * 
 * @param course - pointer to the course type 
 * @return void
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  /**
   * prints all the students by looping over the students array in the course type
   */
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This function filters the student having the highest average in the course
 * 
 * @param course - pointer to the course type 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  // initializing max_average and student variables to the first student in the student array
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  /**
   * looping over the students array of the course type to find the student having the highest average in the course. 
   */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief This function creates a list of all students who have an average higher than 50 in the course (50 is the passing average).
 * 
 * @param course - pointer to the course type
 * @param total_passing - pointer to an integer
 * @return Student* - pointer of student type
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  /**
   * A for loop counting the number of the students who pass the course.
   * 
   */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  /**
   * Dynamically allocates the memory in the heap to store the array of students to be returned.
   * This uses the number of students passing the course obtained by the first for loop of the function
   */
  passing = calloc(count, sizeof(Student));

  int j = 0;

  /**
   * A for loop adding each student in the array of the students who are passing the course.
   * 
   */
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }
  // updating the "pass by reference" variable to the total number of students passing the course
  *total_passing = count;

  return passing;
}