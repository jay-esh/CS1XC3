/**
 * @file course.c
 * @author your name (you@domain.com)
 * @brief consists of funcitons related to the courses and the students 
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief This function enrolls a student into the course by adding the student in the students array in the course type 
 * 
 * @param course - pointer to the course type
 * @param student - pointer to the student type 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    /**
     * calloc is used here to allocate the memory in the heap to add the first element of the grades array
     * 
     */
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      /**
       * realloc is used here to realloc the memory of the array in the heap (add by 1) to add one more student into the array of students in the course type 
       * 
       */
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This function prints the course in the terminal 
 * 
 * @param course - pointer to the course type 
 * @return void 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  /**
   * prints all the students by looping over the students array in the course type
   * 
   */
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This function filters the student having the highest average in the course
 * 
 * @param course - pointer to the course type 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  /**
   * looping over the students array of the course type to find the student having the highest average in the course.
   * 
   */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief This function creates a list of all students who have an average higher than 50 in the course (50 is the passing average).
 * 
 * @param course - pointer to the course type
 * @param total_passing - pointer to an int
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  /**
   * A for loop counting the number of the students who pass.
   * 
   */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  /**
   * Dynamically allocates the memory in the heap to store the array of students to be returned.
   * 
   */
  passing = calloc(count, sizeof(Student));

  int j = 0;

  /**
   * A for loop adding each student in the array of the students who are passing the course.
   * 
   */
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}