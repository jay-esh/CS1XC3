/**
 * @file course.h
 * @author Jayesh Anil
 * @brief A header file consists of course struct and other function declerations
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief a course type stores name, code of the course along with the number of students taking the course 
 * 
 */
typedef struct course 
{
  char name[100]; /**< name of the course in string */
  char code[10]; /**< code of the course in string */
  Student *students; /**< an array of students in the course*/
  int total_students; /**< the total number of students in the course or total number of elements in the students array*/
} Course; 

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


