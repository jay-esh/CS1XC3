/**
 * 
 * @file student.h
 * @author Jayesh Anil
 * @date 2022-04-07
 * @brief A file consisting of function declarations and a student class 
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief a course type stores name, code of the course along with the number of students taking the course 
 * 
 */
typedef struct _course 
{
  char name[100]; /**< name of the course */
  char code[10]; /**< code of the course*/
  Student *students; /**< an array of students in the course*/
  int total_students; /**< the total number of students in the course*/
} Course; 

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


