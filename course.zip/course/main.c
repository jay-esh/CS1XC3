/**
 * @file main.c
 * @mainpage title STUDENTS AND COURSES  
 * @author Jayesh Anil
 * @brief The file using all the libraries for the ultimate battle
 * @version 0.1
 * @date 2022-04-07
 * \image html nft.png
 * \image latex application.eps "my nft" width=5cm
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This function creates a MATH101 course 
 * 
 * @return int 
 */
int main()
{
  /**
   * Some random number generator TODO
   */
  srand((unsigned) time(NULL));

  /**
   * calloc allocates memory in heap to store the course MATH101
   * strcpy assigns the name and the code of the course by copying the string input 
   * 
   */
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  /**
   * enrolls 20 random students in the course using a for loop
   * 
   */
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}